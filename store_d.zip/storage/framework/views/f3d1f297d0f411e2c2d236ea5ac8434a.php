<?php $__env->startSection('template_title'); ?>
    <?php echo e($stock->name ?? "{{ __('Show') Stock"); ?>}}
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Stock</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('stocks.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Marca:</strong>
                            <?php echo e($stock->marca); ?>

                        </div>
                        <div class="form-group">
                            <strong>Modelo:</strong>
                            <?php echo e($stock->modelo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Memoria:</strong>
                            <?php echo e($stock->memoria); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($stock->estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Color:</strong>
                            <?php echo e($stock->color); ?>

                        </div>
                        <div class="form-group">
                            <strong>Stock:</strong>
                            <?php echo e($stock->stock); ?>

                        </div>
                        <div class="form-group">
                            <strong>Imagen:</strong>
                            <?php echo e($stock->img); ?>

                        </div>
                        <div class="form-group">
                            <strong>Descripcion:</strong>
                            <?php echo e($stock->descripcion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Precio U$S:</strong>
                            <?php echo e($stock->precio); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store_d\store_d\resources\views/stocks/show.blade.php ENDPATH**/ ?>