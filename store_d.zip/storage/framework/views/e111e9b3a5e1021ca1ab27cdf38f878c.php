<?php $__env->startSection('template_title'); ?>
    <?php echo e($stock->name ?? "{{ __('Show') Stock"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title"><?php echo e(__('Show')); ?> Stock</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('stocks.index')); ?>"> <?php echo e(__('Back')); ?></a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Marca:</strong>
                            <?php echo e($stock->marca); ?>

                        </div>
                        <div class="form-group">
                            <strong>Modelo:</strong>
                            <?php echo e($stock->modelo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($stock->estado); ?>

                        </div>
                        <div class="form-group">
                            <strong>Color:</strong>
                            <?php echo e($stock->color); ?>

                        </div>
                        <div class="form-group">
                            <strong>Stock:</strong>
                            <?php echo e($stock->stock); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store_d\store_d\resources\views/stock/show.blade.php ENDPATH**/ ?>