@extends("layouts.template")
@section('content')

        <img src="storage/imagenes/test.jpg" class="img-fluid" id="imagenprincipal" style="width:100%; " alt="imagen">
        <h3 class=" container bg-dark" id="texto-principal" style="">Nos especializamos en venta de dispositivos Apple iPhone. En nuestra pagina encontraras modelos nuevos en caja sellada con garantia 1 año oficial de Apple y usados de alta calidad con bateria 85%+ y garantia de 30 dias.</h3>
    


@endsection
